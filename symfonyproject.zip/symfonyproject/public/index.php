<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
require __DIR__ . '/../bootstrap/app.php';

$app->run();
