// $.validator.setDefaults({
//   submitHandler: function() {
//     alert("submitted!");
//   }
// });


jQuery("#form").validate({

});



jQuery(document).ready( function ($) {
   $('#djvtable').DataTable();




} );



