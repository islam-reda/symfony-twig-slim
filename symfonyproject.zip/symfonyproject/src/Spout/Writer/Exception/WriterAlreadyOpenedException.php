<?php

namespace Box\Spout\Writer\Exception;

/**
 * Class WriterAlreadyOpenedException
 *
 * @api
 * @package Box\Spout\Writer\Exception
 */
class WriterAlreadyOpenedException extends WriterException
{
}
